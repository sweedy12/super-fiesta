addpath('~/projects/TFOCS-fork');
addpath('~/projects/TFOCS-fork/mexFiles');
