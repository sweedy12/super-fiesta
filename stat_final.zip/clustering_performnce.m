function [per] = clustering_performnce(Z_rec,Z)
%this function gets the original clustering of the data points Z, and the
%recreated clustering of the data points Z_rec, and returns the performance
%measure which is the maximum (over all permutations) fraction of points
%clustered correctly.

per = 0;
%going over all permutations
z_s = size(Z_rec);
n= b_s(2);
P = perms(1:n);
s = size(P);
for i=1:s(1)
    cur_per = 0;
    %going over all supspaces:
    for j=1:s(2)
        if (P(i,Z_rec(j)) == Z(j)) %good clustering, found match.
            cur_per = cur_per + 1;
        end
    end
    if (cur_per > per)
        per = cur_per;
    end
end
per = per / n;
end