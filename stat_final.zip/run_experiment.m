function [alpha] = run_experiment(n,p,d,k,theta,sigma,tol,alpha_start)
%this function get all parameters required for sampling points, and runs
%k-means and SSC on it.

%sampling points
[X,B,Z,alpha] = sample_points(n,p,d,k,theta,sigma,tol,alpha_start);
%running K-means and PCA to reover the clusteing and subspaces. 
[B_km,Z_km] = run_k_means_pca(X,k,d);


end