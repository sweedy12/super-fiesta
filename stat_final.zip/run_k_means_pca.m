function [B,Z] = run_k_means_pca(X,k,d)
%this function gets data points X, and performs K-means to cluster them.
%Later, in order to find the supspace from which each cluster was drawn
%from, we perform PCA on every set of data points from X that correspond to
%the same cluster. 
%return values - B is the a cell containing the subspaces, Z is a vector
%containing the clustering identities for each point.

%performing K-means:
Z = kmeans(X,k);
B = cell(1,k);
%going through all clusters, performing PCA:
for i=1:k
    clu_ind = find(Z==i);
    clu_points = X(clu_ind,:);
    coeff = PCA(clu_points);
    %taking the leading d components
    B{i} = coeff(1:d,:);
    
end
Z = Z'; %transposing Z to match previous dimension calls.

end